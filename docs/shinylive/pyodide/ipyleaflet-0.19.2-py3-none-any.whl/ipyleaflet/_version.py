# Copyright (c) Jupyter Development Team.
# Distributed under the terms of the Modified BSD License.

EXTENSION_VERSION = "^0.19"
__version__ = "0.19.2"
